@file:Suppress("DEPRECATION")

package com.belajar.capstoneapp.ui.screen.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import com.google.common.util.concurrent.ListenableFuture
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    var isCameraPermissionGranted by remember { mutableStateOf(false) }

    val requestPermissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            // Update state berdasarkan izin yang diberikan atau ditolak
            // dan tampilkan konten kamera atau pesan izin ditolak
            isCameraPermissionGranted = isGranted
        }

    DisposableEffect(context) {
        if (!isCameraPermissionGranted) {
            // Jika tidak ada izin kamera, minta izin
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        onDispose {
            // Cleanup jika diperlukan
        }
    }

    if (isCameraPermissionGranted) {
        CameraContent()
    } else {
        RequestPermissionScreen()
    }
}

@Composable
fun CameraContent() {
    val cameraProviderFuture: ListenableFuture<ProcessCameraProvider> =
        ProcessCameraProvider.getInstance(LocalContext.current)

    val context = LocalContext.current

    DisposableEffect(context) {
        val cameraProvider = cameraProviderFuture.get()

        val lifecycleObserver = AppLifecycleObserver(cameraProvider)
        (context as? ComponentActivity)?.lifecycle?.addObserver(lifecycleObserver)

        onDispose {
            (context as? ComponentActivity)?.lifecycle?.removeObserver(lifecycleObserver)
        }
    }
    CameraPreview(cameraProviderFuture)
}

@Composable
fun RequestPermissionScreen() {
    Text("Please grant camera permission")
}

fun hasRequiredPermissions(context: Context): Boolean {
    val cameraPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    return cameraPermission
}

@Composable
fun CameraPreview(cameraProviderFuture: ListenableFuture<ProcessCameraProvider>) {
    val context = LocalContext.current
    val previewView = PreviewView(context)

    val imageCapture = ImageCapture.Builder().build()

    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

    val cameraProvider = cameraProviderFuture.get()

    val preview = Preview.Builder().build().also {
        it.setSurfaceProvider(previewView.surfaceProvider)
    }

    try {
        cameraProvider.bindToLifecycle(
            (context as? ComponentActivity)!!,
            cameraSelector,
            imageCapture,
            preview
        )
    } catch (e: Exception) {
        Log.e("CameraPreview", "Error binding camera use cases", e)
        Toast.makeText(context, "Error binding camera use cases", Toast.LENGTH_SHORT).show()
    }

    previewView
}

class AppLifecycleObserver(private val cameraProvider: ProcessCameraProvider) : LifecycleObserver {

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onStart() {
        bindCameraUseCases()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onStop() {
        cameraProvider.unbindAll()
        executor.shutdown()
    }

    private fun bindCameraUseCases() {
        Log.d("AppLifecycleObserver", "Binding camera use cases")

        // Add any additional camera use cases if needed
    }
}
